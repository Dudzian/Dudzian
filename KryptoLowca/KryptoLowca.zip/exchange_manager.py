# exchange_manager.py
# -*- coding: utf-8 -*-
"""Shim dla starszych importów ExchangeManager."""
from __future__ import annotations

from managers.exchange_manager import *  # noqa: F401,F403
