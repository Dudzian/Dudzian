Daily Trend – smoke test paper trading
======================================

Ten katalog zawiera artefakty pojedynczego uruchomienia trybu --paper-smoke.
Na potrzeby audytu:

1. Zweryfikuj hash SHA-256 pliku summary.json zapisany w logu CLI oraz w alertach.
2. Przepisz treść summary.txt do dziennika audytowego (docs/audit/paper_trading_log.md).
3. Zabezpiecz ledger.jsonl (pełna historia decyzji) w repozytorium operacyjnym.
4. Zarchiwizowany plik ZIP można przechowywać w sejfie audytu przez min. 24 miesiące.

